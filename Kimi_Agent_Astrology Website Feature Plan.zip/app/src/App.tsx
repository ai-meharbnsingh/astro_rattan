import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import Hero from './sections/Hero';
import Navigation from './sections/Navigation';
import Features from './sections/Features';
import About from './sections/About';
import DailyHoroscope from './sections/DailyHoroscope';
import Panchang from './sections/Panchang';
import Testimonials from './sections/Testimonials';
import SpiritualLibrary from './sections/SpiritualLibrary';
import CTA from './sections/CTA';
import Footer from './sections/Footer';
import AIChat from './sections/AIChat';
import KundliGenerator from './sections/KundliGenerator';
import Shop from './sections/Shop';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const [showAIChat, setShowAIChat] = useState(false);
  const [showKundli, setShowKundli] = useState(false);
  const [showShop, setShowShop] = useState(false);
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.animate-section').forEach((section) => {
        gsap.fromTo(section, 
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: section,
              start: 'top 80%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      });
    }, mainRef);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={mainRef} className="min-h-screen bg-minimal-white text-minimal-gray-800 overflow-x-hidden">
      <Navigation 
        onAIChat={() => setShowAIChat(true)}
        onKundli={() => setShowKundli(true)}
        onShop={() => setShowShop(true)}
      />
      
      <main>
        <Hero onAIChat={() => setShowAIChat(true)} onKundli={() => setShowKundli(true)} />
        <Features onAIChat={() => setShowAIChat(true)} onKundli={() => setShowKundli(true)} />
        <About />
        <DailyHoroscope />
        <Panchang />
        <SpiritualLibrary />
        <Shop preview onFullShop={() => setShowShop(true)} />
        <Testimonials />
        <CTA onAIChat={() => setShowAIChat(true)} />
      </main>
      
      <Footer />
      
      <Dialog open={showAIChat} onOpenChange={setShowAIChat}>
        <DialogContent className="max-w-4xl h-[80vh] bg-white border-minimal-gray-200">
          <AIChat />
        </DialogContent>
      </Dialog>
      
      <Dialog open={showKundli} onOpenChange={setShowKundli}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-white border-minimal-gray-200">
          <KundliGenerator />
        </DialogContent>
      </Dialog>
      
      <Dialog open={showShop} onOpenChange={setShowShop}>
        <DialogContent className="max-w-6xl h-[90vh] overflow-y-auto bg-white border-minimal-gray-200">
          <Shop />
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default App;
