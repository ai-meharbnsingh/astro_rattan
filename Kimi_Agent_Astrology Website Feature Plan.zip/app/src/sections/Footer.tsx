import { Stars, Mail, Phone, Facebook, Twitter, Instagram, Youtube, ChevronRight, Heart } from 'lucide-react';

const footerLinks = {
  services: ['Kundli Generation', 'Daily Horoscope', 'Panchang', 'AI Astrologer', 'Kundli Matching', 'Dosha Analysis'],
  spiritual: ['Bhagavad Gita', 'Sacred Mantras', 'Aarti Collection', 'Pooja Vidhi', 'Vrat Katha', 'Chalisa'],
  shop: ['Gemstones', 'Rudraksha', 'Bracelets', 'Yantras', 'Vastu Products', 'Idols'],
  company: ['About Us', 'Our Astrologers', 'Careers', 'Blog', 'Contact', 'FAQ'],
};

export default function Footer() {
  return (
    <footer className="relative bg-minimal-gray-900 overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-minimal-indigo/50 to-transparent" />
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-16 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
          <div className="col-span-2 md:col-span-3 lg:col-span-2">
            <a href="#" className="flex items-center gap-2 mb-6">
              <div className="w-12 h-12 rounded-full bg-minimal-indigo flex items-center justify-center">
                <Stars className="w-7 h-7 text-white" />
              </div>
              <span className="font-display font-bold text-2xl text-white">AstroMitra</span>
            </a>
            <p className="text-minimal-gray-400 mb-6 max-w-sm">Bridging ancient Vedic wisdom with modern AI technology to guide you through life&apos;s journey.</p>
            <div className="space-y-3 mb-6">
              <a href="mailto:support@astromitra.com" className="flex items-center gap-3 text-minimal-gray-400 hover:text-minimal-indigo transition-colors">
                <Mail className="w-5 h-5" /><span className="text-sm">support@astromitra.com</span>
              </a>
              <a href="tel:+919876543210" className="flex items-center gap-3 text-minimal-gray-400 hover:text-minimal-indigo transition-colors">
                <Phone className="w-5 h-5" /><span className="text-sm">+91 98765 43210</span>
              </a>
            </div>
            <div className="flex gap-3">
              {[Facebook, Twitter, Instagram, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full bg-minimal-gray-800 flex items-center justify-center text-minimal-gray-400 hover:text-minimal-indigo hover:bg-minimal-gray-700 transition-all">
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="font-display font-semibold text-white mb-4 capitalize">{title}</h4>
              <ul className="space-y-2">
                {links.map((link, i) => (
                  <li key={i}>
                    <a href="#" className="text-sm text-minimal-gray-400 hover:text-minimal-indigo transition-colors flex items-center gap-1">
                      <ChevronRight className="w-3 h-3" />{link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="py-6 border-t border-minimal-gray-800 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-minimal-gray-500">&copy; {new Date().getFullYear()} AstroMitra. Made with <Heart className="w-4 h-4 inline text-red-500 fill-red-500" /> in India</p>
          <div className="flex gap-6">
            {['Privacy Policy', 'Terms of Service', 'Refund Policy'].map((item, i) => (
              <a key={i} href="#" className="text-sm text-minimal-gray-500 hover:text-minimal-indigo transition-colors">{item}</a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
