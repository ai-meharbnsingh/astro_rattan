import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Brain, Star, Calendar, BookOpen, Sparkles, ChevronRight, Compass } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface FeaturesProps {
  onAIChat: () => void;
  onKundli: () => void;
}

const features = [
  { icon: Star, title: 'Kundli Analysis', description: 'Generate detailed birth charts with planetary positions and insights.', color: 'indigo', action: 'Generate Kundli' },
  { icon: Calendar, title: 'Daily Panchang', description: 'Stay aligned with cosmic rhythms. Get daily Tithi, Nakshatra, and more.', color: 'violet', action: 'View Panchang' },
  { icon: Brain, title: 'AI Astrologer', description: 'Ask anything about your future, relationships, or spiritual growth.', color: 'blue', action: 'Ask AI' },
  { icon: BookOpen, title: 'Spiritual Library', description: 'Access ancient wisdom from Bhagavad Gita, mantras, and pooja guides.', color: 'indigo', action: 'Explore' },
  { icon: Sparkles, title: 'Dosha Analysis', description: 'Identify Mangal Dosha, Kaal Sarp, and get personalized remedies.', color: 'violet', action: 'Check Dosha' },
  { icon: Compass, title: 'Muhurat Finder', description: 'Find auspicious times for marriage, business, and life events.', color: 'blue', action: 'Find Muhurat' },
];

export default function Features({ onAIChat, onKundli }: FeaturesProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.features-title', { y: 50, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', scrollTrigger: { trigger: sectionRef.current, start: 'top 80%' } });
      gsap.fromTo('.feature-card', { y: 80, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, stagger: 0.1, ease: 'power3.out', scrollTrigger: { trigger: sectionRef.current, start: 'top 70%' } });
    }, sectionRef);
    return () => ctx.revert();
  }, []);
  
  const handleAction = (action: string) => {
    if (action === 'Ask AI') onAIChat();
    else if (action === 'Generate Kundli' || action === 'Check Dosha') onKundli();
  };
  
  return (
    <section ref={sectionRef} id="features" className="relative py-24 bg-white">
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="features-title text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-minimal-indigo/10 text-minimal-indigo text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />Our Services
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold text-minimal-gray-900 mb-4">
            Unlock the Secrets of<span className="text-gradient-indigo"> Vedic Astrology</span>
          </h2>
          <p className="text-lg text-minimal-gray-500 max-w-2xl mx-auto">
            Discover ancient Vedic wisdom combined with modern AI technology
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index} className="feature-card group relative bg-minimal-gray-50 border-0 hover:shadow-soft-lg transition-all duration-300">
                <CardContent className="relative p-6">
                  <div className="w-12 h-12 rounded-xl bg-minimal-indigo/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <Icon className="w-6 h-6 text-minimal-indigo" />
                  </div>
                  <h3 className="text-xl font-display font-semibold text-minimal-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-sm text-minimal-gray-500 mb-4">{feature.description}</p>
                  <Button variant="ghost" size="sm" onClick={() => handleAction(feature.action)} className="p-0 h-auto text-minimal-indigo hover:bg-transparent">
                    {feature.action}<ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
        <div className="features-title mt-16 text-center">
          <p className="text-minimal-gray-500 mb-4">Not sure where to start? Try our AI Astrologer</p>
          <Button onClick={onAIChat} className="bg-minimal-indigo text-white hover:bg-minimal-violet">
            <Brain className="w-5 h-5 mr-2" />Chat with AI Astrologer<ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </div>
    </section>
  );
}
