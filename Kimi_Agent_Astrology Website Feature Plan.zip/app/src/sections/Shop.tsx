import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShoppingBag, Gem, Star, ChevronRight, ShoppingCart } from 'lucide-react';

interface ShopProps {
  preview?: boolean;
  onFullShop?: () => void;
}

const products = [
  { id: 1, name: 'Yellow Sapphire', category: 'Gemstones', price: 12999, rating: 4.8, reviews: 234, badge: 'Bestseller' },
  { id: 2, name: 'Blue Sapphire', category: 'Gemstones', price: 18999, rating: 4.9, reviews: 189, badge: 'Premium' },
  { id: 3, name: 'Rudraksha Mala', category: 'Rudraksha', price: 1299, rating: 4.7, reviews: 567, badge: 'Popular' },
  { id: 4, name: 'Navratna Bracelet', category: 'Bracelets', price: 3499, rating: 4.6, reviews: 312, badge: 'New' },
];

export default function Shop({ preview = false, onFullShop }: ShopProps) {
  const [cart, setCart] = useState<number[]>([]);
  const addToCart = (id: number) => { if (!cart.includes(id)) setCart([...cart, id]); };
  const formatPrice = (price: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(price);
  
  if (preview) {
    return (
      <section id="shop" className="relative py-24 bg-minimal-gray-50">
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-minimal-indigo/10 text-minimal-indigo text-sm font-medium mb-6">
              <ShoppingBag className="w-4 h-4" />Astro Shop
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold text-minimal-gray-900 mb-4">
              Sacred<span className="text-gradient-indigo"> Products</span>
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <Card key={product.id} className="group bg-white border-0 hover:shadow-soft-lg transition-all">
                <CardContent className="p-0">
                  <div className="relative aspect-square bg-minimal-gray-100 flex items-center justify-center">
                    <Gem className="w-12 h-12 text-minimal-indigo" />
                    {product.badge && <Badge className="absolute top-3 left-3 bg-minimal-indigo text-white">{product.badge}</Badge>}
                  </div>
                  <div className="p-4">
                    <p className="text-xs text-minimal-gray-400 mb-1">{product.category}</p>
                    <h3 className="font-display font-semibold text-minimal-gray-900 mb-2">{product.name}</h3>
                    <div className="flex items-center gap-1 mb-3">
                      <Star className="w-4 h-4 text-minimal-indigo fill-minimal-indigo" />
                      <span className="text-sm text-minimal-gray-600">{product.rating}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-bold text-minimal-indigo">{formatPrice(product.price)}</span>
                      <Button size="sm" onClick={() => addToCart(product.id)} className="bg-minimal-indigo/10 text-minimal-indigo hover:bg-minimal-indigo hover:text-white">
                        <ShoppingCart className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-12">
            <Button onClick={onFullShop} className="bg-minimal-indigo text-white hover:bg-minimal-violet">
              <ShoppingBag className="w-5 h-5 mr-2" />View All Products<ChevronRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </div>
      </section>
    );
  }
  
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-display font-bold text-minimal-gray-900">Astro Shop</h2>
          <p className="text-sm text-minimal-gray-500">Authentic spiritual products</p>
        </div>
        <button className="relative">
          <ShoppingCart className="w-6 h-6 text-minimal-indigo" />
          {cart.length > 0 && <span className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-minimal-indigo text-white text-xs flex items-center justify-center">{cart.length}</span>}
        </button>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {products.map((product) => (
          <Card key={product.id} className="bg-white border-0 shadow-soft">
            <CardContent className="p-4">
              <div className="relative aspect-square bg-minimal-gray-100 flex items-center justify-center mb-4">
                <Gem className="w-10 h-10 text-minimal-indigo" />
              </div>
              <h3 className="font-display font-semibold text-minimal-gray-900">{product.name}</h3>
              <p className="text-lg font-bold text-minimal-indigo mt-2">{formatPrice(product.price)}</p>
              <Button size="sm" onClick={() => addToCart(product.id)} className="w-full mt-3 bg-minimal-indigo text-white">Add to Cart</Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
