import { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar, Clock, Sunrise, Sunset, Star } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const panchangData = {
  date: new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
  tithi: { name: 'Shukla Paksha - Pratipada', endTime: '08:45 AM' },
  nakshatra: { name: 'Ashwini', endTime: '06:23 PM' },
  yoga: { name: 'Vriddhi', endTime: '11:30 AM' },
  karana: { name: 'Bava', endTime: '08:45 AM' },
};

const choghadiyaData = {
  day: [
    { name: 'Amrit', time: '06:00 - 07:30', type: 'good' },
    { name: 'Kaal', time: '07:30 - 09:00', type: 'bad' },
    { name: 'Shubh', time: '09:00 - 10:30', type: 'good' },
    { name: 'Rog', time: '10:30 - 12:00', type: 'bad' },
  ],
  night: [
    { name: 'Shubh', time: '18:00 - 19:30', type: 'good' },
    { name: 'Amrit', time: '19:30 - 21:00', type: 'good' },
    { name: 'Char', time: '21:00 - 22:30', type: 'good' },
  ]
};

export default function Panchang() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [currentTime] = useState(new Date());
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.panchang-title', { y: 50, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', scrollTrigger: { trigger: sectionRef.current, start: 'top 80%' } });
    }, sectionRef);
    return () => ctx.revert();
  }, []);
  
  return (
    <section ref={sectionRef} id="panchang" className="relative py-24 bg-minimal-gray-50">
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="panchang-title text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-minimal-violet/10 text-minimal-violet text-sm font-medium mb-6">
            <Calendar className="w-4 h-4" />Daily Panchang
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold text-minimal-gray-900 mb-4">
            Cosmic Timekeeping with<span className="text-gradient-indigo"> Panchang</span>
          </h2>
        </div>
        <div className="bg-white rounded-2xl p-4 mb-8 flex flex-wrap items-center justify-between gap-4 shadow-soft">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-minimal-indigo/10 flex items-center justify-center">
              <Calendar className="w-6 h-6 text-minimal-indigo" />
            </div>
            <div>
              <p className="text-sm text-minimal-gray-500">Today</p>
              <p className="text-lg font-display font-semibold text-minimal-gray-900">{panchangData.date}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-minimal-violet/10 flex items-center justify-center">
              <Clock className="w-6 h-6 text-minimal-violet" />
            </div>
            <div>
              <p className="text-sm text-minimal-gray-500">Current Time</p>
              <p className="text-lg font-display font-semibold text-minimal-gray-900">{currentTime.toLocaleTimeString('en-IN')}</p>
            </div>
          </div>
        </div>
        <div className="grid lg:grid-cols-3 gap-6">
          <Card className="bg-white border-0 shadow-soft">
            <CardContent className="p-6">
              <h3 className="text-xl font-display font-semibold text-minimal-gray-900 mb-6 flex items-center gap-2">
                <Star className="w-5 h-5 text-minimal-indigo" />Today&apos;s Panchang
              </h3>
              <div className="space-y-4">
                {Object.entries(panchangData).filter(([key]) => key !== 'date').map(([key, value]: [string, any]) => (
                  <div key={key} className="p-4 rounded-xl bg-minimal-gray-50">
                    <p className="text-sm text-minimal-gray-500 capitalize">{key}</p>
                    <p className="text-minimal-gray-900 font-medium">{typeof value === 'object' ? value.name : value}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          <Card className="bg-white border-0 shadow-soft">
            <CardContent className="p-6">
              <Tabs defaultValue="day">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-display font-semibold text-minimal-gray-900">Choghadiya</h3>
                  <TabsList className="bg-minimal-gray-100">
                    <TabsTrigger value="day" className="data-[state=active]:bg-minimal-indigo data-[state=active]:text-white">Day</TabsTrigger>
                    <TabsTrigger value="night" className="data-[state=active]:bg-minimal-indigo data-[state=active]:text-white">Night</TabsTrigger>
                  </TabsList>
                </div>
                {['day', 'night'].map((period) => (
                  <TabsContent key={period} value={period} className="mt-0">
                    <div className="space-y-2">
                      {choghadiyaData[period as keyof typeof choghadiyaData].map((item, index) => (
                        <div key={index} className={`flex items-center justify-between p-3 rounded-xl ${item.type === 'good' ? 'bg-green-50' : 'bg-red-50'}`}>
                          <div>
                            <p className={`text-sm font-medium ${item.type === 'good' ? 'text-green-600' : 'text-red-500'}`}>{item.name}</p>
                            <p className="text-xs text-minimal-gray-400">{item.time}</p>
                          </div>
                          <span className={`text-xs px-2 py-1 rounded-full ${item.type === 'good' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-500'}`}>{item.type === 'good' ? 'Good' : 'Avoid'}</span>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </CardContent>
          </Card>
          <Card className="bg-white border-0 shadow-soft">
            <CardContent className="p-6">
              <h3 className="text-xl font-display font-semibold text-minimal-gray-900 mb-6">Sun Times</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 rounded-xl bg-minimal-gray-50">
                  <div className="w-10 h-10 rounded-xl bg-minimal-indigo/10 flex items-center justify-center">
                    <Sunrise className="w-5 h-5 text-minimal-indigo" />
                  </div>
                  <div>
                    <p className="text-sm text-minimal-gray-500">Sunrise</p>
                    <p className="text-minimal-gray-900 font-medium">06:45 AM</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-xl bg-minimal-gray-50">
                  <div className="w-10 h-10 rounded-xl bg-minimal-violet/10 flex items-center justify-center">
                    <Sunset className="w-5 h-5 text-minimal-violet" />
                  </div>
                  <div>
                    <p className="text-sm text-minimal-gray-500">Sunset</p>
                    <p className="text-minimal-gray-900 font-medium">05:52 PM</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
