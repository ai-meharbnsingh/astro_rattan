import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Sparkles, Star, ChevronRight, Calendar, MapPin, Clock } from 'lucide-react';

interface HeroProps {
  onAIChat: () => void;
  onKundli: () => void;
}

export default function Hero({ onAIChat, onKundli }: HeroProps) {
  const heroRef = useRef<HTMLDivElement>(null);
  const [birthDate, setBirthDate] = useState('');
  const [birthTime, setBirthTime] = useState('');
  const [birthPlace, setBirthPlace] = useState('');
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.hero-word',
        { y: 100, opacity: 0 },
        { y: 0, opacity: 1, duration: 1, stagger: 0.1, ease: 'power3.out', delay: 0.5 }
      );
      gsap.fromTo('.hero-subtitle',
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.8, delay: 1, ease: 'power3.out' }
      );
      gsap.fromTo('.hero-form',
        { y: 50, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.8, delay: 1.2, ease: 'power3.out' }
      );
    }, heroRef);
    return () => ctx.revert();
  }, []);
  
  const handleGenerateKundli = () => {
    if (birthDate && birthTime && birthPlace) {
      onKundli();
    }
  };
  
  return (
    <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-b from-minimal-gray-50 to-white">
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-minimal-indigo/10 text-minimal-indigo text-sm font-medium mb-6">
              <Sparkles className="w-4 h-4" />Vedic Astrology
            </div>
            <div className="overflow-hidden mb-4">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold text-minimal-gray-900">
                <span className="hero-word inline-block">Discover</span>{' '}
                <span className="hero-word inline-block">Your</span>
              </h1>
            </div>
            <div className="overflow-hidden mb-4">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold">
                <span className="hero-word inline-block text-gradient-indigo">Cosmic</span>{' '}
                <span className="hero-word inline-block text-minimal-indigo">Path</span>
              </h1>
            </div>
            <p className="hero-subtitle text-lg text-minimal-gray-500 max-w-xl mx-auto lg:mx-0 mb-8">
              Unlock Vedic astrology wisdom with AI-powered insights. Get personalized predictions and spiritual guidance.
            </p>
            <div className="hero-form bg-white rounded-2xl p-6 max-w-md mx-auto lg:mx-0 shadow-soft border border-minimal-gray-100">
              <h3 className="text-lg font-display font-semibold text-minimal-gray-900 mb-4 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-minimal-indigo" />Generate Free Kundli
              </h3>
              <div className="space-y-4">
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-minimal-gray-400" />
                  <Input type="date" value={birthDate} onChange={(e) => setBirthDate(e.target.value)} className="pl-10 bg-minimal-gray-50 border-minimal-gray-200 text-minimal-gray-800" />
                </div>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-minimal-gray-400" />
                  <Input type="time" value={birthTime} onChange={(e) => setBirthTime(e.target.value)} className="pl-10 bg-minimal-gray-50 border-minimal-gray-200 text-minimal-gray-800" />
                </div>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-minimal-gray-400" />
                  <Input type="text" value={birthPlace} onChange={(e) => setBirthPlace(e.target.value)} placeholder="Birth Place" className="pl-10 bg-minimal-gray-50 border-minimal-gray-200 text-minimal-gray-800" />
                </div>
                <Button onClick={handleGenerateKundli} className="w-full bg-minimal-indigo text-white font-medium hover:bg-minimal-violet transition-colors">
                  Generate Kundli<ChevronRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </div>
            <div className="hero-form flex flex-wrap justify-center lg:justify-start gap-4 mt-6">
              <Button variant="outline" onClick={onAIChat} className="border-minimal-gray-300 text-minimal-gray-700 hover:bg-minimal-gray-50">
                <Sparkles className="w-4 h-4 mr-2" />Ask AI Astrologer
              </Button>
            </div>
          </div>
          <div className="hidden lg:flex items-center justify-center">
            <div className="relative w-[400px] h-[400px]">
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-minimal-indigo/10 to-minimal-violet/10" />
              <div className="absolute inset-8 rounded-full bg-gradient-to-br from-minimal-indigo/20 to-minimal-violet/20" />
              <div className="absolute inset-16 rounded-full bg-gradient-to-br from-minimal-indigo to-minimal-violet flex items-center justify-center">
                <Star className="w-24 h-24 text-white" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
