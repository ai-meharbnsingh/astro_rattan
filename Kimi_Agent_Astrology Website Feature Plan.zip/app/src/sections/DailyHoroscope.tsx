import { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sun } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const zodiacSigns = [
  { name: 'Aries', symbol: '♈', date: 'Mar 21 - Apr 19', element: 'Fire' },
  { name: 'Taurus', symbol: '♉', date: 'Apr 20 - May 20', element: 'Earth' },
  { name: 'Gemini', symbol: '♊', date: 'May 21 - Jun 20', element: 'Air' },
  { name: 'Cancer', symbol: '♋', date: 'Jun 21 - Jul 22', element: 'Water' },
  { name: 'Leo', symbol: '♌', date: 'Jul 23 - Aug 22', element: 'Fire' },
  { name: 'Virgo', symbol: '♍', date: 'Aug 23 - Sep 22', element: 'Earth' },
  { name: 'Libra', symbol: '♎', date: 'Sep 23 - Oct 22', element: 'Air' },
  { name: 'Scorpio', symbol: '♏', date: 'Oct 23 - Nov 21', element: 'Water' },
  { name: 'Sagittarius', symbol: '♐', date: 'Nov 22 - Dec 21', element: 'Fire' },
  { name: 'Capricorn', symbol: '♑', date: 'Dec 22 - Jan 19', element: 'Earth' },
  { name: 'Aquarius', symbol: '♒', date: 'Jan 20 - Feb 18', element: 'Air' },
  { name: 'Pisces', symbol: '♓', date: 'Feb 19 - Mar 20', element: 'Water' },
];

const horoscopeData = {
  general: "Today brings positive energy. The planets align in your favor, creating opportunities for growth.",
  love: "Romantic energies are high. If single, you might meet someone special.",
  career: "Professional opportunities on the horizon. Your hard work is being noticed.",
  finance: "Financial stability indicated. Good day for long-term investments.",
  health: "Energy levels rising. Focus on balanced diet and regular exercise.",
};

export default function DailyHoroscope() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [selectedSign, setSelectedSign] = useState(zodiacSigns[0]);
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.horoscope-title', { y: 50, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', scrollTrigger: { trigger: sectionRef.current, start: 'top 80%' } });
    }, sectionRef);
    return () => ctx.revert();
  }, []);
  
  return (
    <section ref={sectionRef} id="horoscope" className="relative py-24 bg-white">
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="horoscope-title text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-minimal-indigo/10 text-minimal-indigo text-sm font-medium mb-6">
            <Sun className="w-4 h-4" />Daily Guidance
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold text-minimal-gray-900 mb-4">
            Your Daily<span className="text-gradient-indigo"> Horoscope</span>
          </h2>
        </div>
        <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-12 gap-3 mb-12">
          {zodiacSigns.map((sign, index) => (
            <button key={index} onClick={() => setSelectedSign(sign)} className={`p-3 rounded-xl transition-all duration-300 ${selectedSign.name === sign.name ? 'bg-minimal-indigo text-white shadow-soft' : 'bg-minimal-gray-50 hover:bg-minimal-indigo/10 text-minimal-gray-700'}`}>
              <span className="text-2xl block mb-1">{sign.symbol}</span>
              <span className="text-xs">{sign.name}</span>
            </button>
          ))}
        </div>
        <div className="grid lg:grid-cols-3 gap-8">
          <Card className="lg:col-span-1 bg-minimal-gray-50 border-0 shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="w-24 h-24 rounded-full bg-minimal-indigo flex items-center justify-center mx-auto mb-4">
                <span className="text-5xl text-white">{selectedSign.symbol}</span>
              </div>
              <h3 className="text-2xl font-display font-bold text-minimal-gray-900 mb-1">{selectedSign.name}</h3>
              <p className="text-sm text-minimal-gray-500 mb-4">{selectedSign.date}</p>
              <span className="px-3 py-1 rounded-full bg-minimal-indigo/10 text-minimal-indigo text-sm">{selectedSign.element}</span>
            </CardContent>
          </Card>
          <Card className="lg:col-span-2 bg-minimal-gray-50 border-0 shadow-soft">
            <CardContent className="p-6">
              <Tabs defaultValue="general">
                <TabsList className="grid grid-cols-5 bg-white mb-6">
                  {['general', 'love', 'career', 'finance', 'health'].map((tab) => (
                    <TabsTrigger key={tab} value={tab} className="data-[state=active]:bg-minimal-indigo data-[state=active]:text-white capitalize">{tab}</TabsTrigger>
                  ))}
                </TabsList>
                {Object.entries(horoscopeData).map(([key, content]) => (
                  <TabsContent key={key} value={key} className="mt-0">
                    <p className="text-minimal-gray-600">{content}</p>
                  </TabsContent>
                ))}
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
