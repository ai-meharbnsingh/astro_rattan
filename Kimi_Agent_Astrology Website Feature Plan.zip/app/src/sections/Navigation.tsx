import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Stars, Menu, X, Sparkles, MessageCircle } from 'lucide-react';

interface NavigationProps {
  onAIChat: () => void;
  onKundli: () => void;
  onShop: () => void;
}

const navLinks = [
  { name: 'Kundli', href: '#kundli' },
  { name: 'Horoscope', href: '#horoscope' },
  { name: 'Panchang', href: '#panchang' },
  { name: 'Shop', href: '#shop' },
];

export default function Navigation({ onAIChat, onKundli, onShop }: NavigationProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 100);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) element.scrollIntoView({ behavior: 'smooth' });
    setIsMobileMenuOpen(false);
  };
  
  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? 'py-3' : 'py-6'}`}>
        <div className={`mx-auto transition-all duration-500 ${isScrolled ? 'max-w-4xl px-6' : 'max-w-7xl px-4 sm:px-6 lg:px-8'}`}>
          <div className={`flex items-center justify-between transition-all duration-500 ${isScrolled ? 'glass-minimal rounded-full px-6 py-3 shadow-soft' : ''}`}>
            <a href="#" className="flex items-center gap-2 group" onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>
              <div className="w-10 h-10 rounded-full bg-minimal-indigo flex items-center justify-center">
                <Stars className="w-6 h-6 text-white" />
              </div>
              <span className={`font-display font-bold text-xl ${isScrolled ? 'text-minimal-gray-900' : 'text-minimal-gray-900'}`}>AstroMitra</span>
            </a>
            <div className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) => (
                <button key={link.name} onClick={() => { if (link.name === 'Kundli') onKundli(); else if (link.name === 'Shop') onShop(); else scrollToSection(link.href); }} className="px-4 py-2 text-sm text-minimal-gray-600 hover:text-minimal-indigo transition-colors">
                  {link.name}
                </button>
              ))}
            </div>
            <div className="hidden lg:flex items-center gap-3">
              <Button variant="ghost" size="sm" onClick={onAIChat} className="text-minimal-gray-600 hover:text-minimal-indigo">
                <MessageCircle className="w-4 h-4 mr-2" />Ask AI
              </Button>
              <Button size="sm" onClick={onKundli} className="bg-minimal-indigo text-white hover:bg-minimal-violet">
                <Sparkles className="w-4 h-4 mr-2" />Get Kundli
              </Button>
            </div>
            <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="lg:hidden p-2 text-minimal-gray-700">
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </nav>
      <div className={`fixed inset-0 z-40 lg:hidden transition-all duration-500 ${isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'}`}>
        <div className="absolute inset-0 bg-white/95 backdrop-blur-xl" onClick={() => setIsMobileMenuOpen(false)} />
        <div className={`absolute top-20 left-4 right-4 glass-minimal rounded-2xl p-6 transition-all duration-500 ${isMobileMenuOpen ? 'translate-y-0 opacity-100' : '-translate-y-10 opacity-0'}`}>
          <div className="space-y-4">
            {navLinks.map((link) => (
              <button key={link.name} onClick={() => { if (link.name === 'Kundli') onKundli(); else if (link.name === 'Shop') onShop(); else scrollToSection(link.href); }} className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-minimal-gray-50 text-left">
                <span className="text-minimal-gray-700 font-medium">{link.name}</span>
              </button>
            ))}
            <div className="pt-4 border-t border-minimal-gray-200 space-y-3">
              <Button className="w-full bg-minimal-indigo text-white" onClick={() => { onAIChat(); setIsMobileMenuOpen(false); }}>
                <MessageCircle className="w-4 h-4 mr-2" />Ask AI Astrologer
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
