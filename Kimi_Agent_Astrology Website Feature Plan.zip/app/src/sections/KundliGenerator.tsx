import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sparkles, Calendar, Clock, MapPin, User, ChevronRight, Download, Share2 } from 'lucide-react';

const planetaryData = [
  { planet: 'Sun', sign: 'Sagittarius', house: 5, status: 'Exalted' },
  { planet: 'Moon', sign: 'Aries', house: 9, status: 'Normal' },
  { planet: 'Mars', sign: 'Scorpio', house: 4, status: 'Own Sign' },
  { planet: 'Mercury', sign: 'Capricorn', house: 6, status: 'Normal' },
  { planet: 'Jupiter', sign: 'Taurus', house: 10, status: 'Normal' },
  { planet: 'Venus', sign: 'Libra', house: 3, status: 'Own Sign' },
  { planet: 'Saturn', sign: 'Aquarius', house: 7, status: 'Own Sign' },
  { planet: 'Rahu', sign: 'Pisces', house: 8, status: 'Normal' },
  { planet: 'Ketu', sign: 'Virgo', house: 2, status: 'Normal' },
];

const doshaAnalysis = {
  mangal: { present: true, severity: 'Low', description: 'Mild Mangal Dosha detected. Remedies recommended.' },
  kaalsarp: { present: false, severity: 'None', description: 'No Kaal Sarp Dosha detected.' },
  sadesati: { present: false, severity: 'None', description: 'Shani Sade Sati is not active.' },
};

export default function KundliGenerator() {
  const [step, setStep] = useState<'form' | 'generating' | 'result'>('form');
  const [formData, setFormData] = useState({ name: '', date: '', time: '', place: '', gender: 'male' as 'male' | 'female' });
  
  const handleGenerate = () => {
    if (formData.name && formData.date && formData.time && formData.place) {
      setStep('generating');
      setTimeout(() => setStep('result'), 3000);
    }
  };
  
  if (step === 'generating') {
    return (
      <div className="flex flex-col items-center justify-center h-full py-20">
        <div className="relative w-32 h-32 mb-8">
          <div className="absolute inset-0 rounded-full border-4 border-minimal-gray-200" />
          <div className="absolute inset-0 rounded-full border-4 border-minimal-indigo border-t-transparent animate-spin" />
          <div className="absolute inset-4 rounded-full bg-minimal-indigo/10 flex items-center justify-center">
            <Sparkles className="w-10 h-10 text-minimal-indigo animate-pulse" />
          </div>
        </div>
        <h3 className="text-2xl font-display font-bold text-minimal-gray-900 mb-2">Generating Your Kundli</h3>
        <p className="text-minimal-gray-500">Analyzing planetary positions...</p>
      </div>
    );
  }
  
  if (step === 'result') {
    return (
      <div className="flex flex-col h-full bg-white">
        <div className="flex items-center justify-between p-4 border-b border-minimal-gray-200">
          <div>
            <h3 className="font-display font-bold text-xl text-minimal-gray-900">{formData.name}&apos;s Kundli</h3>
            <p className="text-xs text-minimal-gray-500">{formData.date} • {formData.time}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="border-minimal-gray-300 text-minimal-gray-700">
              <Share2 className="w-4 h-4 mr-2" />Share
            </Button>
            <Button size="sm" className="bg-minimal-indigo text-white">
              <Download className="w-4 h-4 mr-2" />Download
            </Button>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          <Tabs defaultValue="planets">
            <TabsList className="grid grid-cols-3 bg-minimal-gray-100 mb-4">
              <TabsTrigger value="planets" className="data-[state=active]:bg-minimal-indigo data-[state=active]:text-white">Planets</TabsTrigger>
              <TabsTrigger value="dosha" className="data-[state=active]:bg-minimal-indigo data-[state=active]:text-white">Dosha</TabsTrigger>
              <TabsTrigger value="predictions" className="data-[state=active]:bg-minimal-indigo data-[state=active]:text-white">Future</TabsTrigger>
            </TabsList>
            <TabsContent value="planets">
              <div className="bg-minimal-gray-50 rounded-2xl overflow-hidden">
                <table className="w-full">
                  <thead className="bg-minimal-indigo/10">
                    <tr>
                      <th className="text-left p-4 text-minimal-indigo font-medium">Planet</th>
                      <th className="text-left p-4 text-minimal-indigo font-medium">Sign</th>
                      <th className="text-left p-4 text-minimal-indigo font-medium">House</th>
                      <th className="text-left p-4 text-minimal-indigo font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {planetaryData.map((planet, index) => (
                      <tr key={index} className="border-t border-minimal-gray-200">
                        <td className="p-4 text-minimal-gray-900 font-medium">{planet.planet}</td>
                        <td className="p-4 text-minimal-gray-600">{planet.sign}</td>
                        <td className="p-4 text-minimal-gray-600">{planet.house}</td>
                        <td className="p-4">
                          <span className={`text-xs px-2 py-1 rounded-full ${planet.status === 'Exalted' || planet.status === 'Own Sign' ? 'bg-green-100 text-green-600' : 'bg-minimal-gray-200 text-minimal-gray-600'}`}>
                            {planet.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>
            <TabsContent value="dosha">
              <div className="grid gap-4">
                {Object.entries(doshaAnalysis).map(([key, data]) => (
                  <div key={key} className={`bg-minimal-gray-50 rounded-xl p-4 border ${data.present ? 'border-red-200' : 'border-green-200'}`}>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-display font-semibold text-minimal-gray-900 capitalize">{key === 'mangal' ? 'Mangal Dosha' : key === 'kaalsarp' ? 'Kaal Sarp Dosha' : 'Shani Sade Sati'}</h4>
                      <span className={`text-xs px-2 py-1 rounded-full ${data.present ? 'bg-red-100 text-red-500' : 'bg-green-100 text-green-600'}`}>{data.present ? 'Present' : 'Not Present'}</span>
                    </div>
                    <p className="text-sm text-minimal-gray-600">{data.description}</p>
                  </div>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="predictions">
              <div className="space-y-4">
                {['General', 'Career', 'Finance', 'Love', 'Health'].map((area) => (
                  <div key={area} className="bg-minimal-gray-50 rounded-xl p-4">
                    <h4 className="font-display font-semibold text-minimal-indigo mb-2">{area}</h4>
                    <p className="text-sm text-minimal-gray-600">Positive developments expected in this area.</p>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col h-full bg-white p-6">
      <div className="text-center mb-8">
        <div className="w-16 h-16 rounded-full bg-minimal-indigo flex items-center justify-center mx-auto mb-4">
          <Sparkles className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-2xl font-display font-bold text-minimal-gray-900 mb-2">Generate Your Kundli</h3>
        <p className="text-minimal-gray-500">Enter your birth details</p>
      </div>
      <div className="space-y-4 max-w-md mx-auto w-full">
        <div className="relative">
          <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-minimal-gray-400" />
          <Input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} placeholder="Full Name" className="pl-10 bg-minimal-gray-50 border-minimal-gray-200 text-minimal-gray-900" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <button onClick={() => setFormData({ ...formData, gender: 'male' })} className={`p-3 rounded-xl border transition-colors ${formData.gender === 'male' ? 'border-minimal-indigo bg-minimal-indigo/10 text-minimal-indigo' : 'border-minimal-gray-200 text-minimal-gray-600'}`}>Male</button>
          <button onClick={() => setFormData({ ...formData, gender: 'female' })} className={`p-3 rounded-xl border transition-colors ${formData.gender === 'female' ? 'border-minimal-indigo bg-minimal-indigo/10 text-minimal-indigo' : 'border-minimal-gray-200 text-minimal-gray-600'}`}>Female</button>
        </div>
        <div className="relative">
          <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-minimal-gray-400" />
          <Input type="date" value={formData.date} onChange={(e) => setFormData({ ...formData, date: e.target.value })} className="pl-10 bg-minimal-gray-50 border-minimal-gray-200 text-minimal-gray-900" />
        </div>
        <div className="relative">
          <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-minimal-gray-400" />
          <Input type="time" value={formData.time} onChange={(e) => setFormData({ ...formData, time: e.target.value })} className="pl-10 bg-minimal-gray-50 border-minimal-gray-200 text-minimal-gray-900" />
        </div>
        <div className="relative">
          <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-minimal-gray-400" />
          <Input type="text" value={formData.place} onChange={(e) => setFormData({ ...formData, place: e.target.value })} placeholder="Birth Place" className="pl-10 bg-minimal-gray-50 border-minimal-gray-200 text-minimal-gray-900" />
        </div>
        <Button onClick={handleGenerate} disabled={!formData.name || !formData.date || !formData.time || !formData.place} className="w-full bg-minimal-indigo text-white font-semibold hover:bg-minimal-violet disabled:opacity-50">
          <Sparkles className="w-5 h-5 mr-2" />Generate Kundli<ChevronRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </div>
  );
}
