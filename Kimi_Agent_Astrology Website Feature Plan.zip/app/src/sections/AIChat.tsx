import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Sparkles, Send, User, Bot, Sun, Heart, Briefcase, Coins, Users, BookOpen } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
}

const quickQuestions = [
  { icon: Heart, text: 'Tell me about my love life', category: 'love' },
  { icon: Briefcase, text: 'Career prospects for 2025', category: 'career' },
  { icon: Coins, text: 'Financial predictions', category: 'finance' },
  { icon: Users, text: 'When will I get married?', category: 'marriage' },
  { icon: Sun, text: 'Daily horoscope', category: 'horoscope' },
  { icon: BookOpen, text: 'Gita wisdom', category: 'gita' },
];

const sampleResponses: Record<string, string> = {
  love: 'Based on your chart, Venus is positioned favorably. If single, you may meet someone special between April and June 2025.',
  career: 'Your 10th house shows steady professional growth. The period after 2026 will bring significant career growth.',
  finance: 'Financial stability is indicated. Good period for long-term investments. Avoid risky speculation until August 2025.',
  marriage: 'Your 7th house indicates marriage prospects are strong. Favorable period: June 2025 - December 2025.',
  horoscope: 'Today brings positive energy. Lucky Number: 7, Lucky Color: Indigo.',
  gita: '"You have a right to perform your prescribed duties, but you are not entitled to the fruits of your actions."',
  default: 'Thank you for your question! To provide accurate insights, I would need to analyze your birth chart.',
};

export default function AIChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'ai',
      content: `Namaste! I am your AI Astrologer.\n\nI can help you with:\n• Daily horoscope and predictions\n• Career and financial guidance\n• Love and relationship insights\n• Spiritual wisdom from the Gita\n\nHow may I assist you today?`,
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  useEffect(() => scrollToBottom(), [messages]);
  
  const handleSend = async (text: string = input) => {
    if (!text.trim()) return;
    const userMessage: Message = { id: Date.now().toString(), type: 'user', content: text, timestamp: new Date() };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);
    
    const lowerText = text.toLowerCase();
    let category = 'default';
    if (lowerText.includes('love')) category = 'love';
    else if (lowerText.includes('career')) category = 'career';
    else if (lowerText.includes('finance')) category = 'finance';
    else if (lowerText.includes('marriage')) category = 'marriage';
    else if (lowerText.includes('horoscope')) category = 'horoscope';
    else if (lowerText.includes('gita')) category = 'gita';
    
    setTimeout(() => {
      const aiMessage: Message = { id: (Date.now() + 1).toString(), type: 'ai', content: sampleResponses[category] || sampleResponses.default, timestamp: new Date() };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1500);
  };
  
  return (
    <div className="flex flex-col h-full bg-white">
      <div className="flex items-center gap-3 p-4 border-b border-minimal-gray-200">
        <div className="w-10 h-10 rounded-full bg-minimal-indigo flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="font-display font-semibold text-minimal-gray-900">AI Astrologer</h3>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-xs text-minimal-gray-500">Online</span>
          </div>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div key={message.id} className={`flex gap-3 ${message.type === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${message.type === 'user' ? 'bg-minimal-violet/20' : 'bg-minimal-indigo'}`}>
              {message.type === 'user' ? <User className="w-4 h-4 text-minimal-violet" /> : <Bot className="w-4 h-5 text-white" />}
            </div>
            <div className={`max-w-[80%] ${message.type === 'user' ? 'text-right' : ''}`}>
              <div className={`inline-block p-4 rounded-2xl text-left ${message.type === 'user' ? 'bg-minimal-violet/20 text-minimal-gray-900' : 'bg-minimal-gray-100 text-minimal-gray-900'}`}>
                <div className="whitespace-pre-line text-sm">{message.content}</div>
              </div>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-minimal-indigo flex items-center justify-center">
              <Bot className="w-4 h-5 text-white" />
            </div>
            <div className="bg-minimal-gray-100 p-4 rounded-2xl">
              <div className="flex gap-2">
                <span className="w-2 h-2 rounded-full bg-minimal-indigo animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-minimal-indigo animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 rounded-full bg-minimal-indigo animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      {messages.length < 3 && (
        <div className="px-4 py-3 border-t border-minimal-gray-200">
          <p className="text-xs text-minimal-gray-400 mb-2">Quick Questions:</p>
          <div className="flex gap-2 overflow-x-auto">
            {quickQuestions.map((q, i) => (
              <button key={i} onClick={() => handleSend(q.text)} className="flex items-center gap-2 px-3 py-2 rounded-full bg-minimal-gray-100 text-xs text-minimal-gray-600 hover:text-minimal-indigo whitespace-nowrap">
                <q.icon className="w-3 h-3" />{q.text}
              </button>
            ))}
          </div>
        </div>
      )}
      <div className="p-4 border-t border-minimal-gray-200">
        <div className="flex gap-3">
          <Input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSend()} placeholder="Ask anything..." className="flex-1 bg-minimal-gray-50 border-minimal-gray-200 text-minimal-gray-900" />
          <Button onClick={() => handleSend()} disabled={!input.trim() || isTyping} className="bg-minimal-indigo text-white hover:bg-minimal-violet disabled:opacity-50">
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
