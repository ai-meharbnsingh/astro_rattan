import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BookOpen, Music, Flame, ChevronRight, Play, Sparkles } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const spiritualContent = {
  gita: [
    { title: 'Chapter 1: Arjuna\'s Dilemma', verses: 47, description: 'Arjuna faces moral confusion on the battlefield.' },
    { title: 'Chapter 2: Sankhya Yoga', verses: 72, description: 'The eternal nature of the soul and duty.' },
    { title: 'Chapter 3: Karma Yoga', verses: 43, description: 'The path of selfless action.' },
    { title: 'Chapter 4: Jnana Yoga', verses: 42, description: 'Divine knowledge and wisdom.' },
  ],
  mantras: [
    { name: 'Gayatri Mantra', deity: 'Goddess Gayatri', benefit: 'Wisdom' },
    { name: 'Mahamrityunjaya', deity: 'Lord Shiva', benefit: 'Health' },
    { name: 'Hanuman Chalisa', deity: 'Lord Hanuman', benefit: 'Strength' },
    { name: 'Vishnu Sahasranama', deity: 'Lord Vishnu', benefit: 'Peace' },
  ],
  aarti: [
    { name: 'Om Jai Jagdish Hare', deity: 'Lord Vishnu' },
    { name: 'Jai Ganesh Deva', deity: 'Lord Ganesha' },
    { name: 'Om Jai Shiv Omkara', deity: 'Lord Shiva' },
    { name: 'Jai Lakshmi Mata', deity: 'Goddess Lakshmi' },
  ],
};

export default function SpiritualLibrary() {
  const sectionRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.spiritual-title', { y: 50, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', scrollTrigger: { trigger: sectionRef.current, start: 'top 80%' } });
    }, sectionRef);
    return () => ctx.revert();
  }, []);
  
  return (
    <section ref={sectionRef} id="spiritual" className="relative py-24 bg-white">
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="spiritual-title text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-minimal-indigo/10 text-minimal-indigo text-sm font-medium mb-6">
            <BookOpen className="w-4 h-4" />Sacred Wisdom
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold text-minimal-gray-900 mb-4">
            Spiritual<span className="text-gradient-indigo"> Library</span>
          </h2>
        </div>
        <Tabs defaultValue="gita" className="w-full">
          <TabsList className="grid grid-cols-3 max-w-md mx-auto mb-8 bg-minimal-gray-100">
            <TabsTrigger value="gita" className="data-[state=active]:bg-minimal-indigo data-[state=active]:text-white"><BookOpen className="w-4 h-4 mr-2" />Gita</TabsTrigger>
            <TabsTrigger value="mantras" className="data-[state=active]:bg-minimal-violet data-[state=active]:text-white"><Music className="w-4 h-4 mr-2" />Mantras</TabsTrigger>
            <TabsTrigger value="aarti" className="data-[state=active]:bg-minimal-blue data-[state=active]:text-white"><Flame className="w-4 h-4 mr-2" />Aarti</TabsTrigger>
          </TabsList>
          <TabsContent value="gita" className="mt-0">
            <div className="grid md:grid-cols-2 gap-6">
              {spiritualContent.gita.map((chapter, index) => (
                <Card key={index} className="group bg-minimal-gray-50 border-0 hover:shadow-soft-lg transition-all">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-xl bg-minimal-indigo/10 flex items-center justify-center mb-4">
                      <BookOpen className="w-6 h-6 text-minimal-indigo" />
                    </div>
                    <h3 className="text-xl font-display font-semibold text-minimal-gray-900 mb-2">{chapter.title}</h3>
                    <p className="text-sm text-minimal-gray-500 mb-4">{chapter.description}</p>
                    <span className="text-xs text-minimal-indigo">{chapter.verses} Verses</span>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="mantras" className="mt-0">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {spiritualContent.mantras.map((mantra, index) => (
                <Card key={index} className="group bg-minimal-gray-50 border-0 hover:shadow-soft-lg transition-all text-center">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-xl bg-minimal-violet/10 flex items-center justify-center mx-auto mb-4">
                      <Music className="w-6 h-6 text-minimal-violet" />
                    </div>
                    <h3 className="text-lg font-display font-semibold text-minimal-gray-900 mb-1">{mantra.name}</h3>
                    <p className="text-sm text-minimal-gray-500">{mantra.deity}</p>
                    <span className="text-xs text-minimal-violet mt-2 inline-block">{mantra.benefit}</span>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="aarti" className="mt-0">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {spiritualContent.aarti.map((aarti, index) => (
                <Card key={index} className="group bg-minimal-gray-50 border-0 hover:shadow-soft-lg transition-all text-center">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-xl bg-minimal-blue/10 flex items-center justify-center mx-auto mb-4">
                      <Flame className="w-6 h-6 text-minimal-blue" />
                    </div>
                    <h3 className="text-lg font-display font-semibold text-minimal-gray-900 mb-1">{aarti.name}</h3>
                    <p className="text-sm text-minimal-gray-500">{aarti.deity}</p>
                    <Button variant="ghost" size="sm" className="mt-3 text-minimal-blue">
                      <Play className="w-4 h-4 mr-2" />Play
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
        <div className="mt-16">
          <Card className="bg-minimal-gray-50 border-0 shadow-soft overflow-hidden">
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-minimal-indigo/10 text-minimal-indigo text-sm font-medium mb-4">
                    <Sparkles className="w-4 h-4" />AI Powered
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-display font-bold text-minimal-gray-900 mb-4">
                    Ask AI About the<span className="text-gradient-indigo"> Bhagavad Gita</span>
                  </h3>
                  <Button className="bg-minimal-indigo text-white hover:bg-minimal-violet">
                    <Sparkles className="w-5 h-5 mr-2" />Ask AI Gita<ChevronRight className="w-5 h-5 ml-2" />
                  </Button>
                </div>
                <div className="relative aspect-square max-w-sm mx-auto">
                  <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-minimal-indigo/10 to-minimal-violet/10" />
                  <div className="absolute inset-4 rounded-2xl bg-white shadow-soft flex items-center justify-center">
                    <BookOpen className="w-16 h-16 text-minimal-indigo" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
