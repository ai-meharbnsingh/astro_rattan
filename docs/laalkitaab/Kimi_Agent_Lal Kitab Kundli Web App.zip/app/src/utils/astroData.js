// Lal Kitab Astrology Data

export const planets = [
  { id: 'sun', name: 'सूर्य', englishName: 'Sun', color: '#FF6B35', symbol: '☉' },
  { id: 'moon', name: 'चंद्रमा', englishName: 'Moon', color: '#C0C0C0', symbol: '☽' },
  { id: 'mars', name: 'मंगल', englishName: 'Mars', color: '#FF0000', symbol: '♂' },
  { id: 'mercury', name: 'बुध', englishName: 'Mercury', color: '#00FF00', symbol: '☿' },
  { id: 'jupiter', name: 'गुरु', englishName: 'Jupiter', color: '#FFD700', symbol: '♃' },
  { id: 'venus', name: 'शुक्र', englishName: 'Venus', color: '#FF69B4', symbol: '♀' },
  { id: 'saturn', name: 'शनि', englishName: 'Saturn', color: '#4169E1', symbol: '♄' },
  { id: 'rahu', name: 'राहु', englishName: 'Rahu', color: '#800080', symbol: '☊' },
  { id: 'ketu', name: 'केतु', englishName: 'Ketu', color: '#A52A2A', symbol: '☋' }
];

export const zodiacSigns = [
  { id: 'aries', name: 'मेष', englishName: 'Aries', symbol: '♈', element: 'fire' },
  { id: 'taurus', name: 'वृष', englishName: 'Taurus', symbol: '♉', element: 'earth' },
  { id: 'gemini', name: 'मिथुन', englishName: 'Gemini', symbol: '♊', element: 'air' },
  { id: 'cancer', name: 'कर्क', englishName: 'Cancer', symbol: '♋', element: 'water' },
  { id: 'leo', name: 'सिंह', englishName: 'Leo', symbol: '♌', element: 'fire' },
  { id: 'virgo', name: 'कन्या', englishName: 'Virgo', symbol: '♍', element: 'earth' },
  { id: 'libra', name: 'तुला', englishName: 'Libra', symbol: '♎', element: 'air' },
  { id: 'scorpio', name: 'वृश्चिक', englishName: 'Scorpio', symbol: '♏', element: 'water' },
  { id: 'sagittarius', name: 'धनु', englishName: 'Sagittarius', symbol: '♐', element: 'fire' },
  { id: 'capricorn', name: 'मकर', englishName: 'Capricorn', symbol: '♑', element: 'earth' },
  { id: 'aquarius', name: 'कुंभ', englishName: 'Aquarius', symbol: '♒', element: 'air' },
  { id: 'pisces', name: 'मीन', englishName: 'Pisces', symbol: '♓', element: 'water' }
];

export const houses = [
  { number: 1, name: 'प्रथम भाव', englishName: 'First House', significance: 'तन, व्यक्तित्व, स्वास्थ्य' },
  { number: 2, name: 'द्वितीय भाव', englishName: 'Second House', significance: 'धन, परिवार, वाणी' },
  { number: 3, name: 'तृतीय भाव', englishName: 'Third House', significance: 'साहस, भाई-बहन, पराक्रम' },
  { number: 4, name: 'चतुर्थ भाव', englishName: 'Fourth House', significance: 'माता, वाहन, भूमि, सुख' },
  { number: 5, name: 'पंचम भाव', englishName: 'Fifth House', significance: 'संतान, विद्या, सट्टा' },
  { number: 6, name: 'षष्ठम भाव', englishName: 'Sixth House', significance: 'रोग, शत्रु, कर्ज, नौकरी' },
  { number: 7, name: 'सप्तम भाव', englishName: 'Seventh House', significance: 'विवाह, पत्नी, व्यापार' },
  { number: 8, name: 'अष्टम भाव', englishName: 'Eighth House', significance: 'आयु, मृत्यु, अचानक धन' },
  { number: 9, name: 'नवम भाव', englishName: 'Ninth House', significance: 'भाग्य, धर्म, पिता, यात्रा' },
  { number: 10, name: 'दशम भाव', englishName: 'Tenth House', significance: 'कर्म, पद, प्रतिष्ठा' },
  { number: 11, name: 'एकादश भाव', englishName: 'Eleventh House', significance: 'लाभ, मित्र, बड़े भाई' },
  { number: 12, name: 'द्वादश भाव', englishName: 'Twelfth House', significance: 'व्यय, मोक्ष, विदेश' }
];

export const lalKitabDebts = [
  { id: 'pitra', name: 'पितृ ऋण', planet: 'sun', description: 'पिता या पूर्वजों से संबंधित ऋण' },
  { id: 'matra', name: 'मातृ ऋण', planet: 'moon', description: 'माता से संबंधित ऋण' },
  { id: 'bhratri', name: 'भ्रातृ ऋण', planet: 'mars', description: 'भाई बहनों से संबंधित ऋण' },
  { id: 'dev', name: 'देव ऋण', planet: 'jupiter', description: 'देवताओं या गुरु से संबंधित ऋण' },
  { id: 'stri', name: 'स्त्री ऋण', planet: 'venus', description: 'स्त्रियों से संबंधित ऋण' },
  { id: 'shatru', name: 'शत्रु ऋण', planet: 'saturn', description: 'शत्रुओं या कर्म से संबंधित ऋण' },
  { id: 'pitamah', name: 'पितामह ऋण', planet: 'rahu', description: 'पूर्वजों या नाना से संबंधित ऋण' },
  { id: 'prapitamah', name: 'प्रपितामह ऋण', planet: 'ketu', description: 'पूर्वजों या दादा से संबंधित ऋण' }
];

export const dashaPeriods = {
  ketu: 7,
  venus: 20,
  sun: 6,
  moon: 10,
  mars: 7,
  rahu: 18,
  jupiter: 16,
  saturn: 19,
  mercury: 17
};

export const planetRelationships = {
  sun: { friends: ['moon', 'mars', 'jupiter'], enemies: ['venus', 'saturn'], neutral: ['mercury'] },
  moon: { friends: ['sun', 'mercury'], enemies: ['rahu', 'ketu'], neutral: ['mars', 'jupiter', 'venus', 'saturn'] },
  mars: { friends: ['sun', 'moon', 'jupiter'], enemies: ['mercury'], neutral: ['venus', 'saturn', 'rahu', 'ketu'] },
  mercury: { friends: ['sun', 'venus'], enemies: ['moon'], neutral: ['mars', 'jupiter', 'saturn', 'rahu', 'ketu'] },
  jupiter: { friends: ['sun', 'moon', 'mars'], enemies: ['mercury', 'venus'], neutral: ['saturn', 'rahu', 'ketu'] },
  venus: { friends: ['mercury', 'saturn', 'rahu', 'ketu'], enemies: ['sun', 'moon'], neutral: ['mars', 'jupiter'] },
  saturn: { friends: ['mercury', 'venus', 'rahu', 'ketu'], enemies: ['sun', 'moon', 'mars'], neutral: ['jupiter'] },
  rahu: { friends: ['venus', 'saturn', 'ketu'], enemies: ['sun', 'moon', 'mars'], neutral: ['mercury', 'jupiter'] },
  ketu: { friends: ['venus', 'saturn', 'rahu'], enemies: ['sun', 'moon', 'mars'], neutral: ['mercury', 'jupiter'] }
};

export const exaltationSigns = {
  sun: 'aries',
  moon: 'taurus',
  mars: 'capricorn',
  mercury: 'virgo',
  jupiter: 'cancer',
  venus: 'pisces',
  saturn: 'libra',
  rahu: 'gemini',
  ketu: 'sagittarius'
};

export const debilitationSigns = {
  sun: 'libra',
  moon: 'scorpio',
  mars: 'cancer',
  mercury: 'pisces',
  jupiter: 'capricorn',
  venus: 'virgo',
  saturn: 'aries',
  rahu: 'sagittarius',
  ketu: 'gemini'
};

export const mooltrikonaSigns = {
  sun: 'leo',
  moon: 'cancer',
  mars: 'aries',
  mercury: 'virgo',
  jupiter: 'sagittarius',
  venus: 'libra',
  saturn: 'aquarius',
  rahu: 'gemini',
  ketu: 'sagittarius'
};
