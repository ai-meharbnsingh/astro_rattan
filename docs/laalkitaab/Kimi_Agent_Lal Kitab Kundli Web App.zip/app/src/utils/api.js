const API_BASE_URL = 'http://localhost:5000/api';

export const api = {
  // Auth endpoints
  register: async (userData) => {
    const response = await fetch(`${API_BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userData)
    });
    return response.json();
  },

  login: async (credentials) => {
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials)
    });
    return response.json();
  },

  getCurrentUser: async (token) => {
    const response = await fetch(`${API_BASE_URL}/auth/me`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },

  // Kundli endpoints
  createKundli: async (kundliData, token) => {
    const response = await fetch(`${API_BASE_URL}/kundli/create`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(kundliData)
    });
    return response.json();
  },

  getKundlis: async (token) => {
    const response = await fetch(`${API_BASE_URL}/kundli/list`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },

  getKundli: async (id, token) => {
    const response = await fetch(`${API_BASE_URL}/kundli/${id}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },

  deleteKundli: async (id, token) => {
    const response = await fetch(`${API_BASE_URL}/kundli/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },

  // Predictions endpoints
  getNishaniyan: async (kundliId, token) => {
    const response = await fetch(`${API_BASE_URL}/predictions/nishaniyan/${kundliId}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },

  getDebts: async (kundliId, token) => {
    const response = await fetch(`${API_BASE_URL}/predictions/debts/${kundliId}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },

  getMarriagePrediction: async (kundliId, token) => {
    const response = await fetch(`${API_BASE_URL}/predictions/marriage/${kundliId}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },

  getCareerPrediction: async (kundliId, token) => {
    const response = await fetch(`${API_BASE_URL}/predictions/career/${kundliId}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },

  getHealthPrediction: async (kundliId, token) => {
    const response = await fetch(`${API_BASE_URL}/predictions/health/${kundliId}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },

  getWealthPrediction: async (kundliId, token) => {
    const response = await fetch(`${API_BASE_URL}/predictions/wealth/${kundliId}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },

  // Remedies endpoints
  getRemedies: async (kundliId, token) => {
    const response = await fetch(`${API_BASE_URL}/remedies/${kundliId}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },

  getPlanetRemedies: async (planet, token) => {
    const response = await fetch(`${API_BASE_URL}/remedies/planet/${planet}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  }
};
