import React from 'react';
import { Star, Book, History, Sparkles } from 'lucide-react';

const About = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-orange-600 to-red-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Star className="w-16 h-16 mx-auto mb-4 text-yellow-300" />
          <h1 className="text-4xl md:text-5xl font-bold mb-4">About Lal Kitab</h1>
          <p className="text-xl text-orange-100 max-w-2xl mx-auto">
            Understanding the ancient wisdom of Lal Kitab astrology
          </p>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
            <div className="flex items-center mb-6">
              <Book className="w-8 h-8 text-orange-500 mr-3" />
              <h2 className="text-2xl font-bold text-gray-800">What is Lal Kitab?</h2>
            </div>
            <p className="text-gray-600 mb-4 leading-relaxed">
              Lal Kitab (literally meaning "Red Book") is a unique system of astrology that originated in Punjab, India 
              during the 19th century. Unlike traditional Vedic astrology, Lal Kitab provides simple, practical, and 
              effective remedies (Upay) that anyone can perform to improve their life and overcome obstacles.
            </p>
            <p className="text-gray-600 mb-4 leading-relaxed">
              The Lal Kitab system is based on the concept of "Nishaniyan" (signs) - specific indications that appear 
              in a person's birth chart based on planetary positions. These signs help identify problems and their 
              solutions in a person's life.
            </p>
            <p className="text-gray-600 leading-relaxed">
              One of the unique features of Lal Kitab is its introduction of the concept of "Rin" (debts) - karmic 
              debts from past lives that affect our present life. Understanding and clearing these debts through 
              specific remedies can bring positive changes and happiness.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
            <div className="flex items-center mb-6">
              <History className="w-8 h-8 text-orange-500 mr-3" />
              <h2 className="text-2xl font-bold text-gray-800">History of Lal Kitab</h2>
            </div>
            <p className="text-gray-600 mb-4 leading-relaxed">
              The original Lal Kitab was written in Urdu and Persian languages. The authorship is traditionally 
              attributed to Pandit Roop Chand Joshi (1898-1982) of Pharwala, Punjab. He is said to have received 
              this knowledge through divine inspiration.
            </p>
            <p className="text-gray-600 mb-4 leading-relaxed">
              The Lal Kitab consists of five volumes, each dealing with different aspects of astrology and remedies. 
              The first edition was published in 1939, and subsequent editions followed in 1940, 1941, 1942, and 1952.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Over the years, Lal Kitab has gained immense popularity due to its simplicity and effectiveness. 
              Today, it is practiced and followed by millions of people across the world.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
            <div className="flex items-center mb-6">
              <Sparkles className="w-8 h-8 text-orange-500 mr-3" />
              <h2 className="text-2xl font-bold text-gray-800">Key Features of Lal Kitab</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-orange-50 rounded-lg p-4">
                <h3 className="font-bold text-orange-700 mb-2">Nishaniyan (Signs)</h3>
                <p className="text-gray-600 text-sm">
                  Specific indications in the birth chart that reveal problems and their causes in a person's life.
                </p>
              </div>
              <div className="bg-orange-50 rounded-lg p-4">
                <h3 className="font-bold text-orange-700 mb-2">Rin (Debts)</h3>
                <p className="text-gray-600 text-sm">
                  Karmic debts from past lives that create obstacles in the present life.
                </p>
              </div>
              <div className="bg-orange-50 rounded-lg p-4">
                <h3 className="font-bold text-orange-700 mb-2">Teva System</h3>
                <p className="text-gray-600 text-sm">
                  Classification of birth charts based on planetary positions and their effects.
                </p>
              </div>
              <div className="bg-orange-50 rounded-lg p-4">
                <h3 className="font-bold text-orange-700 mb-2">Simple Remedies</h3>
                <p className="text-gray-600 text-sm">
                  Easy-to-perform remedies that don't require elaborate rituals or expensive materials.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">The Nine Planets in Lal Kitab</h2>
            <div className="space-y-4">
              {[
                { name: 'Sun (Surya)', description: 'Represents soul, father, authority, and government.' },
                { name: 'Moon (Chandra)', description: 'Represents mind, mother, emotions, and public.' },
                { name: 'Mars (Mangal)', description: 'Represents courage, siblings, property, and energy.' },
                { name: 'Mercury (Budh)', description: 'Represents intelligence, communication, and business.' },
                { name: 'Jupiter (Guru)', description: 'Represents wisdom, children, wealth, and spirituality.' },
                { name: 'Venus (Shukra)', description: 'Represents love, marriage, luxury, and arts.' },
                { name: 'Saturn (Shani)', description: 'Represents karma, delays, discipline, and hard work.' },
                { name: 'Rahu', description: 'Represents illusion, foreign connections, and sudden events.' },
                { name: 'Ketu', description: 'Represents spirituality, detachment, and past life karma.' }
              ].map((planet, idx) => (
                <div key={idx} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2"></div>
                  <div>
                    <span className="font-semibold text-gray-800">{planet.name}:</span>
                    <span className="text-gray-600 ml-2">{planet.description}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
