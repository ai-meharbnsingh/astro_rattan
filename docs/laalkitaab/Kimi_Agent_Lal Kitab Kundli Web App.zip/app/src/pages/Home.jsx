import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Heart, Briefcase, TrendingUp, Shield, BookOpen, ChevronRight } from 'lucide-react';

const Home = () => {
  const features = [
    {
      icon: <Star className="w-8 h-8 text-orange-500" />,
      title: 'Complete Kundli Analysis',
      description: 'Generate detailed birth charts with accurate planetary positions and house analysis.'
    },
    {
      icon: <Heart className="w-8 h-8 text-pink-500" />,
      title: 'Marriage Predictions',
      description: 'Get insights about your marriage timing, spouse characteristics, and compatibility.'
    },
    {
      icon: <Briefcase className="w-8 h-8 text-blue-500" />,
      title: 'Career Guidance',
      description: 'Discover your ideal career path and favourable periods for professional growth.'
    },
    {
      icon: <TrendingUp className="w-8 h-8 text-green-500" />,
      title: 'Wealth Analysis',
      description: 'Understand your financial potential and investment opportunities.'
    },
    {
      icon: <Shield className="w-8 h-8 text-red-500" />,
      title: 'Health Predictions',
      description: 'Know about potential health issues and preventive measures.'
    },
    {
      icon: <BookOpen className="w-8 h-8 text-purple-500" />,
      title: 'Lal Kitab Remedies',
      description: 'Get effective and simple remedies for all your life problems.'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-orange-500 via-red-500 to-pink-600 text-white py-20">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-6">
            <Star className="w-16 h-16 mx-auto text-yellow-300 animate-pulse" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            लाल किताब कुंडली
          </h1>
          <p className="text-xl md:text-2xl mb-4 text-orange-100">
            Lal Kitab Kundli - Your Complete Astrology Solution
          </p>
          <p className="text-lg mb-8 max-w-2xl mx-auto text-orange-50">
            Discover the ancient wisdom of Lal Kitab astrology. Get accurate predictions, 
            detailed analysis, and effective remedies for all aspects of your life.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link 
              to="/create-kundli" 
              className="bg-white text-orange-600 px-8 py-4 rounded-full font-bold text-lg hover:bg-orange-100 transition-all transform hover:scale-105 shadow-lg"
            >
              Create Your Kundli
            </Link>
            <Link 
              to="/features" 
              className="border-2 border-white text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-white hover:text-orange-600 transition-all"
            >
              Learn More
            </Link>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute top-10 left-10 w-20 h-20 bg-yellow-400 rounded-full opacity-20 animate-bounce"></div>
        <div className="absolute bottom-10 right-10 w-32 h-32 bg-pink-400 rounded-full opacity-20 animate-pulse"></div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              Our Astrology Services
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Comprehensive Lal Kitab astrology services to guide you through every aspect of life
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div 
                key={index} 
                className="bg-white rounded-xl shadow-lg p-8 hover:shadow-2xl transition-all transform hover:-translate-y-2"
              >
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lal Kitab Info Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">
                What is Lal Kitab?
              </h2>
              <p className="text-gray-600 mb-4 text-lg">
                Lal Kitab (Red Book) is a unique system of astrology that originated in Punjab, India. 
                Unlike traditional Vedic astrology, Lal Kitab provides simple and practical remedies 
                (Upay) that anyone can perform to improve their life.
              </p>
              <p className="text-gray-600 mb-4 text-lg">
                The system is based on the concept of "Nishaniyan" (signs) - specific indications 
                that appear in a person's birth chart based on planetary positions. These signs help 
                identify problems and their solutions.
              </p>
              <p className="text-gray-600 mb-6 text-lg">
                Lal Kitab also introduces the concept of "Rin" (debts) - karmic debts from past 
                lives that affect our present life. Understanding and clearing these debts through 
                specific remedies can bring positive changes.
              </p>
              <Link 
                to="/about" 
                className="inline-flex items-center text-orange-600 font-semibold hover:text-orange-700"
              >
                Learn More About Lal Kitab <ChevronRight className="w-5 h-5 ml-1" />
              </Link>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-orange-100 to-red-100 rounded-2xl p-8">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white rounded-lg p-4 shadow-md text-center">
                    <div className="text-3xl font-bold text-orange-600 mb-1">9</div>
                    <div className="text-sm text-gray-600">Planets</div>
                  </div>
                  <div className="bg-white rounded-lg p-4 shadow-md text-center">
                    <div className="text-3xl font-bold text-red-600 mb-1">12</div>
                    <div className="text-sm text-gray-600">Houses</div>
                  </div>
                  <div className="bg-white rounded-lg p-4 shadow-md text-center">
                    <div className="text-3xl font-bold text-pink-600 mb-1">108</div>
                    <div className="text-sm text-gray-600">Nishaniyan</div>
                  </div>
                  <div className="bg-white rounded-lg p-4 shadow-md text-center">
                    <div className="text-3xl font-bold text-purple-600 mb-1">100+</div>
                    <div className="text-sm text-gray-600">Remedies</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-orange-600 to-red-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Discover Your Destiny?
          </h2>
          <p className="text-xl mb-8 text-orange-100 max-w-2xl mx-auto">
            Create your Lal Kitab Kundli today and unlock the secrets of your life path 
            with accurate predictions and effective remedies.
          </p>
          <Link 
            to="/register" 
            className="bg-white text-orange-600 px-8 py-4 rounded-full font-bold text-lg hover:bg-orange-100 transition-all transform hover:scale-105 shadow-lg inline-block"
          >
            Get Started Free
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
