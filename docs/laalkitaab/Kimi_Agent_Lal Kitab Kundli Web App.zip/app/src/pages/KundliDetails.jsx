import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { api } from '../utils/api';
import KundliChart from '../components/KundliChart';
import { 
  Loader, ArrowLeft, Star, Heart, Briefcase, 
  TrendingUp, Shield, BookOpen, AlertTriangle, 
  Sparkles, Moon, Sun
} from 'lucide-react';

const KundliDetails = () => {
  const { id } = useParams();
  const { getToken } = useAuth();
  const [kundli, setKundli] = useState(null);
  const [planetaryPositions, setPlanetaryPositions] = useState([]);
  const [activeTab, setActiveTab] = useState('chart');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tabData, setTabData] = useState({});

  useEffect(() => {
    fetchKundliDetails();
  }, [id]);

  const fetchKundliDetails = async () => {
    try {
      const token = getToken();
      const response = await api.getKundli(id, token);
      if (response.success) {
        setKundli(response.kundli);
        setPlanetaryPositions(response.planetary_positions);
      } else {
        setError(response.message);
      }
    } catch (err) {
      setError('Failed to fetch kundli details');
    } finally {
      setLoading(false);
    }
  };

  const fetchTabData = async (tab) => {
    if (tabData[tab]) return;

    try {
      const token = getToken();
      let response;

      switch (tab) {
        case 'nishaniyan':
          response = await api.getNishaniyan(id, token);
          break;
        case 'debts':
          response = await api.getDebts(id, token);
          break;
        case 'marriage':
          response = await api.getMarriagePrediction(id, token);
          break;
        case 'career':
          response = await api.getCareerPrediction(id, token);
          break;
        case 'health':
          response = await api.getHealthPrediction(id, token);
          break;
        case 'wealth':
          response = await api.getWealthPrediction(id, token);
          break;
        case 'remedies':
          response = await api.getRemedies(id, token);
          break;
        default:
          return;
      }

      if (response.success) {
        setTabData(prev => ({ ...prev, [tab]: response }));
      }
    } catch (err) {
      console.error(`Failed to fetch ${tab} data`);
    }
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    if (tab !== 'chart' && tab !== 'planets') {
      fetchTabData(tab);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader className="w-8 h-8 animate-spin text-orange-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="bg-red-50 border border-red-200 text-red-700 px-6 py-4 rounded-lg">
          {error}
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'chart', label: 'Kundli Chart', icon: <Star className="w-4 h-4" /> },
    { id: 'planets', label: 'Planetary Positions', icon: <Sun className="w-4 h-4" /> },
    { id: 'nishaniyan', label: 'Nishaniyan', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'debts', label: 'Lal Kitab Debts', icon: <AlertTriangle className="w-4 h-4" /> },
    { id: 'marriage', label: 'Marriage', icon: <Heart className="w-4 h-4" /> },
    { id: 'career', label: 'Career', icon: <Briefcase className="w-4 h-4" /> },
    { id: 'health', label: 'Health', icon: <Shield className="w-4 h-4" /> },
    { id: 'wealth', label: 'Wealth', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'remedies', label: 'Remedies', icon: <BookOpen className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link 
          to="/dashboard" 
          className="inline-flex items-center text-orange-600 hover:text-orange-700 mb-6"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Dashboard
        </Link>

        {/* Kundli Header */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-800">{kundli?.name}'s Kundli</h1>
              <div className="flex flex-wrap gap-4 mt-2 text-gray-600">
                <span className="flex items-center">
                  <Star className="w-4 h-4 mr-1 text-orange-500" />
                  {formatDate(kundli?.date_of_birth)}
                </span>
                <span className="flex items-center">
                  <Sun className="w-4 h-4 mr-1 text-orange-500" />
                  {kundli?.time_of_birth}
                </span>
                <span className="flex items-center">
                  <Moon className="w-4 h-4 mr-1 text-orange-500" />
                  {kundli?.place_of_birth}
                </span>
              </div>
            </div>
            <div className="mt-4 md:mt-0">
              <span className={`px-4 py-2 rounded-full text-sm font-medium capitalize ${
                kundli?.gender === 'male' ? 'bg-blue-100 text-blue-700' : 
                kundli?.gender === 'female' ? 'bg-pink-100 text-pink-700' : 
                'bg-green-100 text-green-700'
              }`}>
                {kundli?.gender}
              </span>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-lg mb-6 overflow-x-auto">
          <div className="flex space-x-1 p-2 min-w-max">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => handleTabChange(tab.id)}
                className={`flex items-center space-x-2 px-4 py-3 rounded-lg font-medium transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white'
                    : 'text-gray-600 hover:bg-orange-50'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          {/* Kundli Chart Tab */}
          {activeTab === 'chart' && (
            <KundliChart planetaryPositions={planetaryPositions} />
          )}

          {/* Planetary Positions Tab */}
          {activeTab === 'planets' && (
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">Planetary Positions</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-orange-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-orange-800">Planet</th>
                      <th className="px-4 py-3 text-left text-orange-800">House</th>
                      <th className="px-4 py-3 text-left text-orange-800">Zodiac Sign</th>
                      <th className="px-4 py-3 text-left text-orange-800">Degree</th>
                      <th className="px-4 py-3 text-left text-orange-800">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {planetaryPositions.map((pos, idx) => (
                      <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="px-4 py-3 capitalize font-medium">{pos.planet}</td>
                        <td className="px-4 py-3">{pos.house}</td>
                        <td className="px-4 py-3 capitalize">{pos.zodiac_sign}</td>
                        <td className="px-4 py-3">{pos.degree}°</td>
                        <td className="px-4 py-3">
                          {pos.is_retrograde ? (
                            <span className="text-red-600 font-medium">Retrograde</span>
                          ) : (
                            <span className="text-green-600">Direct</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Nishaniyan Tab */}
          {activeTab === 'nishaniyan' && (
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">Nishaniyan (Signs)</h3>
              {tabData.nishaniyan?.nishaniyan?.length > 0 ? (
                <div className="space-y-4">
                  {tabData.nishaniyan.nishaniyan.map((item, idx) => (
                    <div key={idx} className="bg-orange-50 rounded-lg p-4">
                      <div className="flex items-center mb-2">
                        <span className="font-bold text-orange-700 capitalize">{item.planet}</span>
                        <span className="mx-2 text-gray-400">in</span>
                        <span className="font-bold text-orange-700">House {item.house}</span>
                      </div>
                      <div className="text-gray-700">
                        {item.nishanis?.map((n, i) => (
                          <p key={i} className="mb-2">{n.nishani_text}</p>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">Loading nishaniyan...</p>
              )}
            </div>
          )}

          {/* Debts Tab */}
          {activeTab === 'debts' && (
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">Lal Kitab Debts (Rin)</h3>
              {tabData.debts?.debts?.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {tabData.debts.debts.map((item, idx) => (
                    item.debts?.map((debt, dIdx) => (
                      <div key={`${idx}-${dIdx}`} className="bg-red-50 rounded-lg p-4 border-l-4 border-red-500">
                        <h4 className="font-bold text-red-700 mb-2">{debt.debt_type}</h4>
                        <p className="text-gray-700 mb-2">{debt.description}</p>
                        <p className="text-sm text-gray-600 mb-2"><strong>Indication:</strong> {debt.indication}</p>
                        <p className="text-sm text-green-700"><strong>Remedy:</strong> {debt.remedy}</p>
                      </div>
                    ))
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">Loading debts...</p>
              )}
            </div>
          )}

          {/* Marriage Tab */}
          {activeTab === 'marriage' && (
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">Marriage Predictions</h3>
              {tabData.marriage?.marriage_prediction ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-pink-50 rounded-lg p-4 text-center">
                      <p className="text-gray-600 mb-1">Marriage Age</p>
                      <p className="text-2xl font-bold text-pink-600">{tabData.marriage.marriage_prediction.marriage_age}</p>
                    </div>
                    <div className="bg-pink-50 rounded-lg p-4 text-center">
                      <p className="text-gray-600 mb-1">Manglik Status</p>
                      <p className="text-lg font-bold text-pink-600 capitalize">
                        {tabData.marriage.marriage_prediction.manglik_status}
                      </p>
                    </div>
                    <div className="bg-pink-50 rounded-lg p-4 text-center">
                      <p className="text-gray-600 mb-1">Compatibility</p>
                      <p className="text-2xl font-bold text-pink-600">
                        {tabData.marriage.marriage_prediction.compatibility_score}%
                      </p>
                    </div>
                  </div>
                  <div className="bg-white border border-pink-200 rounded-lg p-4">
                    <h4 className="font-bold text-pink-700 mb-2">Spouse Details</h4>
                    <p className="text-gray-700">{tabData.marriage.marriage_prediction.spouse_details}</p>
                  </div>
                  <div className="bg-white border border-pink-200 rounded-lg p-4">
                    <h4 className="font-bold text-pink-700 mb-2">Predictions</h4>
                    <p className="text-gray-700">{tabData.marriage.marriage_prediction.predictions}</p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-4">
                    <h4 className="font-bold text-green-700 mb-2">Remedies</h4>
                    <p className="text-gray-700">{tabData.marriage.marriage_prediction.remedies}</p>
                  </div>
                </div>
              ) : (
                <p className="text-gray-500">Loading marriage predictions...</p>
              )}
            </div>
          )}

          {/* Career Tab */}
          {activeTab === 'career' && (
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">Career Predictions</h3>
              {tabData.career?.career_prediction ? (
                <div className="space-y-4">
                  <div className="bg-blue-50 rounded-lg p-4">
                    <h4 className="font-bold text-blue-700 mb-2">Suitable Careers</h4>
                    <div className="flex flex-wrap gap-2">
                      {tabData.career.career_prediction.suitable_careers?.map((career, idx) => (
                        <span key={idx} className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm">
                          {career}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-white border border-blue-200 rounded-lg p-4">
                      <h4 className="font-bold text-blue-700 mb-2">Business Suitability</h4>
                      <p className="text-gray-700">
                        {tabData.career.career_prediction.business_suitability ? 'Yes' : 'No'}
                      </p>
                    </div>
                    <div className="bg-white border border-blue-200 rounded-lg p-4">
                      <h4 className="font-bold text-blue-700 mb-2">Job Suitability</h4>
                      <p className="text-gray-700">
                        {tabData.career.career_prediction.job_suitability ? 'Yes' : 'No'}
                      </p>
                    </div>
                  </div>
                  <div className="bg-white border border-blue-200 rounded-lg p-4">
                    <h4 className="font-bold text-blue-700 mb-2">Favourable Periods</h4>
                    <p className="text-gray-700">{tabData.career.career_prediction.favourable_periods}</p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-4">
                    <h4 className="font-bold text-green-700 mb-2">Remedies</h4>
                    <p className="text-gray-700">{tabData.career.career_prediction.remedies}</p>
                  </div>
                </div>
              ) : (
                <p className="text-gray-500">Loading career predictions...</p>
              )}
            </div>
          )}

          {/* Health Tab */}
          {activeTab === 'health' && (
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">Health Predictions</h3>
              {tabData.health?.health_prediction ? (
                <div className="space-y-4">
                  <div className="bg-green-50 rounded-lg p-4">
                    <h4 className="font-bold text-green-700 mb-2">General Health</h4>
                    <p className="text-gray-700">{tabData.health.health_prediction.general_health}</p>
                  </div>
                  <div className="bg-white border border-green-200 rounded-lg p-4">
                    <h4 className="font-bold text-green-700 mb-2">Vulnerable Areas</h4>
                    <div className="flex flex-wrap gap-2">
                      {tabData.health.health_prediction.vulnerable_areas?.map((area, idx) => (
                        <span key={idx} className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm">
                          {area}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="bg-green-50 rounded-lg p-4">
                    <h4 className="font-bold text-green-700 mb-2">Precautions</h4>
                    <p className="text-gray-700">{tabData.health.health_prediction.precautions}</p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-4">
                    <h4 className="font-bold text-green-700 mb-2">Remedies</h4>
                    <p className="text-gray-700">{tabData.health.health_prediction.remedies}</p>
                  </div>
                </div>
              ) : (
                <p className="text-gray-500">Loading health predictions...</p>
              )}
            </div>
          )}

          {/* Wealth Tab */}
          {activeTab === 'wealth' && (
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">Wealth Predictions</h3>
              {tabData.wealth?.wealth_prediction ? (
                <div className="space-y-4">
                  <div className="bg-yellow-50 rounded-lg p-4 text-center">
                    <p className="text-gray-600 mb-1">Wealth Potential</p>
                    <p className="text-2xl font-bold text-yellow-600 capitalize">
                      {tabData.wealth.wealth_prediction.wealth_potential}
                    </p>
                  </div>
                  <div className="bg-white border border-yellow-200 rounded-lg p-4">
                    <h4 className="font-bold text-yellow-700 mb-2">Income Sources</h4>
                    <div className="flex flex-wrap gap-2">
                      {tabData.wealth.wealth_prediction.income_sources?.map((source, idx) => (
                        <span key={idx} className="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm">
                          {source}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="bg-white border border-yellow-200 rounded-lg p-4">
                    <h4 className="font-bold text-yellow-700 mb-2">Favourable Periods</h4>
                    <p className="text-gray-700">{tabData.wealth.wealth_prediction.favourable_periods}</p>
                  </div>
                  <div className="bg-white border border-yellow-200 rounded-lg p-4">
                    <h4 className="font-bold text-yellow-700 mb-2">Investment Advice</h4>
                    <p className="text-gray-700">{tabData.wealth.wealth_prediction.investment_advice}</p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-4">
                    <h4 className="font-bold text-green-700 mb-2">Remedies</h4>
                    <p className="text-gray-700">{tabData.wealth.wealth_prediction.remedies}</p>
                  </div>
                </div>
              ) : (
                <p className="text-gray-500">Loading wealth predictions...</p>
              )}
            </div>
          )}

          {/* Remedies Tab */}
          {activeTab === 'remedies' && (
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">Lal Kitab Remedies (Upay)</h3>
              {tabData.remedies?.remedies?.length > 0 ? (
                <div className="space-y-4">
                  {tabData.remedies.remedies.map((item, idx) => (
                    <div key={idx} className="bg-purple-50 rounded-lg p-4">
                      <div className="flex items-center mb-3">
                        <span className="font-bold text-purple-700 capitalize">{item.planet}</span>
                        <span className="mx-2 text-gray-400">in</span>
                        <span className="font-bold text-purple-700">House {item.house}</span>
                      </div>
                      <div className="space-y-2">
                        {item.remedies?.map((remedy, rIdx) => (
                          <div key={rIdx} className="bg-white rounded-lg p-3">
                            <p className="text-gray-700 mb-2">{remedy.remedy_text}</p>
                            {remedy.instructions && (
                              <p className="text-sm text-gray-500"><strong>Instructions:</strong> {remedy.instructions}</p>
                            )}
                            {remedy.duration_days && (
                              <p className="text-sm text-gray-500"><strong>Duration:</strong> {remedy.duration_days} days</p>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500">Loading remedies...</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default KundliDetails;
