import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { api } from '../utils/api';
import { Plus, Calendar, MapPin, User, Trash2, Eye, Star, Loader } from 'lucide-react';

const Dashboard = () => {
  const { user, getToken } = useAuth();
  const [kundlis, setKundlis] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchKundlis();
  }, []);

  const fetchKundlis = async () => {
    try {
      const token = getToken();
      const response = await api.getKundlis(token);
      if (response.success) {
        setKundlis(response.kundlis);
      } else {
        setError(response.message);
      }
    } catch (err) {
      setError('Failed to fetch kundlis');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this kundli?')) {
      return;
    }

    try {
      const token = getToken();
      const response = await api.deleteKundli(id, token);
      if (response.success) {
        setKundlis(kundlis.filter(k => k.id !== id));
      } else {
        setError(response.message);
      }
    } catch (err) {
      setError('Failed to delete kundli');
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader className="w-8 h-8 animate-spin text-orange-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">My Kundlis</h1>
            <p className="text-gray-600 mt-1">Welcome back, {user?.name}!</p>
          </div>
          <Link
            to="/create-kundli"
            className="mt-4 sm:mt-0 bg-gradient-to-r from-orange-500 to-red-500 text-white px-6 py-3 rounded-lg font-semibold hover:from-orange-600 hover:to-red-600 transition-all flex items-center space-x-2"
          >
            <Plus className="w-5 h-5" />
            <span>Create New Kundli</span>
          </Link>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}

        {/* Kundlis Grid */}
        {kundlis.length === 0 ? (
          <div className="bg-white rounded-xl shadow-lg p-12 text-center">
            <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Star className="w-10 h-10 text-orange-500" />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">No Kundlis Yet</h3>
            <p className="text-gray-600 mb-6">Create your first kundli to get started with Lal Kitab astrology</p>
            <Link
              to="/create-kundli"
              className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-6 py-3 rounded-lg font-semibold hover:from-orange-600 hover:to-red-600 transition-all inline-flex items-center space-x-2"
            >
              <Plus className="w-5 h-5" />
              <span>Create Your First Kundli</span>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {kundlis.map((kundli) => (
              <div key={kundli.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                <div className="bg-gradient-to-r from-orange-500 to-red-500 p-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold text-white">{kundli.name}</h3>
                    <div className={`w-3 h-3 rounded-full ${kundli.gender === 'male' ? 'bg-blue-300' : kundli.gender === 'female' ? 'bg-pink-300' : 'bg-green-300'}`}></div>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="space-y-3">
                    <div className="flex items-center text-gray-600">
                      <Calendar className="w-5 h-5 mr-3 text-orange-500" />
                      <span>{formatDate(kundli.date_of_birth)}</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <User className="w-5 h-5 mr-3 text-orange-500" />
                      <span>{kundli.time_of_birth}</span>
                    </div>
                    <div className="flex items-center text-gray-600">
                      <MapPin className="w-5 h-5 mr-3 text-orange-500" />
                      <span className="truncate">{kundli.place_of_birth}</span>
                    </div>
                  </div>

                  <div className="mt-6 flex space-x-3">
                    <Link
                      to={`/kundli/${kundli.id}`}
                      className="flex-1 bg-orange-100 text-orange-600 py-2 px-4 rounded-lg font-medium hover:bg-orange-200 transition-colors flex items-center justify-center space-x-2"
                    >
                      <Eye className="w-4 h-4" />
                      <span>View</span>
                    </Link>
                    <button
                      onClick={() => handleDelete(kundli.id)}
                      className="bg-red-100 text-red-600 py-2 px-4 rounded-lg font-medium hover:bg-red-200 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
