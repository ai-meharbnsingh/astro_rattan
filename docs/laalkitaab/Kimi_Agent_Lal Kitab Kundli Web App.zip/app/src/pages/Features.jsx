import React from 'react';
import { 
  Star, Heart, Briefcase, TrendingUp, Shield, 
  BookOpen, AlertTriangle, Calendar, Sparkles,
  CheckCircle
} from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: <Star className="w-12 h-12 text-orange-500" />,
      title: 'Complete Kundli Analysis',
      description: 'Generate detailed birth charts with accurate planetary positions in all 12 houses. Our system calculates positions for all 9 planets including Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn, Rahu, and Ketu.',
      benefits: [
        'North Indian style kundli chart',
        'Planetary positions with degrees',
        'Retrograde planet identification',
        'Zodiac sign placement'
      ]
    },
    {
      icon: <Sparkles className="w-12 h-12 text-purple-500" />,
      title: 'Nishaniyan (Signs) Analysis',
      description: 'Discover the unique signs (Nishaniyan) that appear in your birth chart based on planetary positions. These signs reveal specific problems and their causes in your life.',
      benefits: [
        '108+ different nishaniyan',
        'Categorized by life areas',
        'Severity indicators',
        'Detailed explanations'
      ]
    },
    {
      icon: <AlertTriangle className="w-12 h-12 text-red-500" />,
      title: 'Lal Kitab Debts (Rin)',
      description: 'Identify the karmic debts (Rin) from your past lives that are affecting your present. Understanding these debts is the first step toward clearing them.',
      benefits: [
        '8 types of karmic debts',
        'Debt identification',
        'Root cause analysis',
        'Clearing methods'
      ]
    },
    {
      icon: <Heart className="w-12 h-12 text-pink-500" />,
      title: 'Marriage Predictions',
      description: 'Get detailed insights about your marriage timing, spouse characteristics, compatibility, and married life. Check for Manglik dosha and its remedies.',
      benefits: [
        'Marriage age prediction',
        'Spouse characteristics',
        'Manglik dosha check',
        'Compatibility analysis'
      ]
    },
    {
      icon: <Briefcase className="w-12 h-12 text-blue-500" />,
      title: 'Career Guidance',
      description: 'Discover your ideal career path based on planetary positions. Get guidance on suitable professions, business vs job suitability, and favourable periods.',
      benefits: [
        'Suitable career options',
        'Business vs job analysis',
        'Favourable periods',
        'Growth opportunities'
      ]
    },
    {
      icon: <Shield className="w-12 h-12 text-green-500" />,
      title: 'Health Analysis',
      description: 'Understand potential health issues and vulnerable areas based on your birth chart. Get preventive measures and health remedies.',
      benefits: [
        'Health vulnerability areas',
        'Preventive measures',
        'Chronic issue indicators',
        'Health remedies'
      ]
    },
    {
      icon: <TrendingUp className="w-12 h-12 text-yellow-500" />,
      title: 'Wealth Predictions',
      description: 'Analyze your financial potential, income sources, investment opportunities, and wealth accumulation periods. Get personalized financial advice.',
      benefits: [
        'Wealth potential analysis',
        'Income source identification',
        'Investment guidance',
        'Favourable periods'
      ]
    },
    {
      icon: <BookOpen className="w-12 h-12 text-indigo-500" />,
      title: 'Lal Kitab Remedies',
      description: 'Get effective and simple remedies (Upay) for all your life problems. These remedies are easy to perform and do not require elaborate rituals.',
      benefits: [
        'Planet-specific remedies',
        'Simple to perform',
        'No expensive materials',
        'Proven effectiveness'
      ]
    },
    {
      icon: <Calendar className="w-12 h-12 text-teal-500" />,
      title: 'Varshphal (Yearly)',
      description: 'Get yearly predictions based on your birth chart. Understand what each year holds for you in terms of career, health, wealth, and relationships.',
      benefits: [
        'Yearly predictions',
        'Muntha analysis',
        'Varsh lord identification',
        'Annual guidance'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-orange-600 to-red-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Sparkles className="w-16 h-16 mx-auto mb-4 text-yellow-300" />
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Features</h1>
          <p className="text-xl text-orange-100 max-w-2xl mx-auto">
            Comprehensive Lal Kitab astrology services to guide you through every aspect of life
          </p>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">{feature.icon}</div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-800 mb-3">{feature.title}</h3>
                    <p className="text-gray-600 mb-4">{feature.description}</p>
                    <ul className="space-y-2">
                      {feature.benefits.map((benefit, bIdx) => (
                        <li key={bIdx} className="flex items-center text-sm text-gray-600">
                          <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-orange-600 to-red-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Explore Your Destiny?</h2>
          <p className="text-xl text-orange-100 mb-8 max-w-2xl mx-auto">
            Create your Lal Kitab Kundli today and unlock all these powerful features
          </p>
          <a 
            href="/create-kundli" 
            className="bg-white text-orange-600 px-8 py-4 rounded-full font-bold text-lg hover:bg-orange-100 transition-all inline-block"
          >
            Create Your Kundli Now
          </a>
        </div>
      </section>
    </div>
  );
};

export default Features;
